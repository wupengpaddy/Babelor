# coding=utf-8
# Copyright 2018 StrTrek Team Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# System Required
import ftplib
import logging
# Outer Required
# Inner Required
from Babelor.Presentation import URL, MSG
from Babelor.Config import GLOBAL_CFG
# Global Parameters
BANNER = GLOBAL_CFG["FTP_BANNER"]
PASV_PORT = GLOBAL_CFG["FTP_PASV_PORTS"]
MAX_CONS = GLOBAL_CFG["FTP_MAX_CONS"]
MAX_CONS_PER_IP = GLOBAL_CFG["FTP_MAX_CONS_PER_IP"]
BUFFER_SIZE = GLOBAL_CFG['FTP_BUFFER_SIZE']


class FTP:
    def __init__(self, conn: URL):
        if isinstance(conn, str):
            self.conn = URL(conn)
        else:
            self.conn = conn
        self.conn = self.__dict__["conn"].check

    def write(self, msg: MSG):
        logging.info("FTP::{0} write:{1}".format(self.conn, msg))
        ftp = self.open()
        for i in range(0, msg.nums, 1):
            attachment = msg.read_datum(i)
            ftp.storbinary('STOR ' + attachment["path"].split("/")[-1], attachment["stream"], BUFFER_SIZE)
        ftp.close()

    def read(self, msg: MSG):
        new_msg = msg
        new_msg.nums = 0
        ftp = self.open()
        for i in range(0, msg.nums, 1):
            attachment = msg.read_datum(i)
            ftp.retrbinary('RETR ' + attachment["path"].split("/")[-1], attachment["stream"], BUFFER_SIZE)
            new_msg.add_datum(datum=attachment["stream"], path=attachment['path'])
        ftp.close()
        logging.info("FTP::{0} read:{1}".format(self.conn, new_msg))
        return new_msg

    def open(self):
        ftp = ftplib.FTP()
        ftp.connect(self.conn.hostname, self.conn.port)
        ftp.login(self.conn.username, self.conn.password)
        # ----------------------------------------------------- 被动模式 - PASV Model
        if isinstance(self.conn.fragment, URL):
            if isinstance(self.conn.fragment.query, dict):
                if self.conn.fragment.query["model"] in ["PASV"]:
                    ftp.set_pasv(True)
            return ftp
